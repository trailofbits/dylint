# template

### What it does

### Why is this bad?

### Known problems

Remove if none.

### Example

```rust
// example code where a warning is issued
```

Use instead:

```rust
// example code that does not raise a warning
```
